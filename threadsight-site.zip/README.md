# ThreadSight — Static Site (Cloudflare Pages)

Dark, sleek static site with gold accent. Deploy to Cloudflare Pages using **dist/** as the output directory (no build step).

## Deploy on Cloudflare Pages
- Project type: `Pages`
- Build command: (leave empty)
- Build output directory: `dist`